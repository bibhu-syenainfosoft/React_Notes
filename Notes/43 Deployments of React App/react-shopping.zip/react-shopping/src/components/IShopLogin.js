import axios from "axios";
import { useFormik } from "formik";
import { useEffect, useState } from "react"
import { useCookies } from "react-cookie";
import { Link, useNavigate} from "react-router-dom"
import * as yup from 'yup';

export default function IShopLogin(){
    const [users,setUsers] = useState([]);
    const [cookie,setCookie,removeCookie]=useCookies();

    const navigate = useNavigate();
    useEffect(()=>{
      axios.get('https://testapps.aquilasoftware.com/CRMV1/maintenance/getRolesList',{
        params:{
        jsonObj:JSON.stringify({
            name: "",
            active: 1,
            upperbound: 1000,
            lowerbound: 1,
            catererId: "compasscrmtest"
        })
        }
    }).then(response=>{
        setUsers(response.data);
    })
    },[]);

    const formik = useFormik({
        initialValues:{
            userId:'',
            password: ''
        },
        validationSchema:yup.object({
            userId:yup.string().required('UserId cannot be empty'),
            password:yup.string().required('Password cannot be empty')
        })
        ,
        onSubmit: (values,{resetForm})=>{
           for(var user of users){
            if(user.name==values.userId && user.description==values.password){
              setCookie('userid',user.name);
              navigate('/dashboard');
              resetForm();
              break;
            }
            else{
                navigate('/errorpage');
                resetForm();
            }
           }
        }
    })

    return(
        <div>
            <form onSubmit={formik.handleSubmit}>
                <dl>
                <dt>User Id <span className="text-danger">*</span></dt>
                <dd><input type="text" {...formik.getFieldProps('userId')} /></dd>
                <dd className="text-danger">{formik.errors.userId}</dd>
                <dt>Password <span className="text-danger">*</span></dt>
                <dd><input type="password" {...formik.getFieldProps('password')} /></dd>
                <dd className="text-danger">{formik.errors.password}</dd>
                </dl>
                <div className="w-25 d-flex mx-5">
                    <div>
                        <button className="btn btn-outline-primary">Login</button>
                    </div>
                    <div className="mx-3 mt-3">
                    <Link to="/register">New User?</Link>
                    </div>
                </div>
            </form>
          
        </div>
    )

}