import { useEffect, useState } from "react"
import { useParams, Link } from "react-router-dom";
import axios from "axios";

export default function IShopProducts() {
    const [category, setCategory] = useState();
    const [products, setProducts] = useState([]);
    const param = useParams();

    useEffect(() => {
        setCategory(param.categories);
        axios.get('https://fakestoreapi.com/products').
            then(response => {
                setProducts(response.data);
            })
    }, []);

    return (
        <div>
            <h3><b><i>{category?.toUpperCase()}</i> List</b></h3>
            <ol>
                {
                    products.filter(item => item.category == category).map(item =>
                        <li key={item.id}>
                            <div>{item.title}</div>
                            <Link to={'/details/' + item.id}><img src={item.image} width='50' height='50' /></Link>
                        </li>
                    )
                }
            </ol>
            <Link className="ms-5" to='/dashboard'>Back to Categories</Link>
        </div>
    )
}