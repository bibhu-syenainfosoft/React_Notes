import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import IShopHome from '../components/IShopHome';
import IShopLogin from '../components/IShopLogin';
import IShopRegister from '../components/IShopRegister';
import IShopDashboard from '../components/IShopDashboard';
import IShopProducts from '../components/IShopProducts';
import IShopProductDetails from '../components/IShopProductDetails';

export default function ShoppingIndex() {

    return (
        <div className='container-fluid'>
            <header className='d-flex justify-content-center py-2 bg-dark text-white'>
                <h2 ><b>IShop-Online Store</b></h2>
            </header>
            <BrowserRouter>
                <div>
                    <section className="row mt-2">
                        <nav className="col-sm-3 col-md-3 col-lg-3">
                            <div className='bg-danger mt-2 py-1 rounded-1 text-center'><Link className='text-white text-decoration-none' to='/home'><h5><b>Home</b></h5></Link></div>
                            <div className='bg-danger mt-2 py-1 rounded-1 text-center'><Link className='text-white text-decoration-none' to='/register'><h5><b>Register</b></h5></Link></div>
                            <div className='bg-danger mt-2 py-1 rounded-1 text-center'><Link className='text-white text-decoration-none' to='/login'><h5><b>Login</b></h5></Link></div>
                            <div className='bg-danger mt-2 py-1 rounded-1 text-center'><Link className='text-white text-decoration-none' to='/dashboard'><h5><b>Dashboard</b></h5></Link></div>
                        </nav>
                        <main className='col-sm-9 col-md-9 col-lg-9 mt-2 overflow-y-auto'>
                            <Routes>
                                <Route path='/' element={<IShopHome />}></Route>
                                <Route path='/home' element={<IShopHome />}></Route>
                                <Route path='/login' element={<IShopLogin />}></Route>
                                <Route path='/register' element={<IShopRegister />}></Route>
                                <Route path='/dashboard' element={<IShopDashboard />}></Route>
                                <Route path='/errorpage' element={
                                    <div className='mt-2'>
                                        <h4 className='text-danger'>Invalid Credentials!!!</h4>
                                        <Link to='/login'>Try Again?</Link>
                                    </div>
                                }>
                                </Route>
                                <Route path='/products/:categories' element={<IShopProducts />}></Route>
                                <Route path='/details/:id' element={<IShopProductDetails />}></Route>
                            </Routes>
                        </main>
                    </section>

                </div>
            </BrowserRouter>
        </div>
    )
}


//https://testapps.aquilasoftware.com/CRMV1/maintenance/getRolesList?jsonObj={ "name": "","active": 1,"upperbound": 10,"lowerbound": 1,"catererId": "compasscrmtest"}



//https://testapps.aquilasoftware.com/CRMV1/maintenance/saveOrUpdateRoles
/*
{
    "id": 0,
    "name": "Test12",
    "updatedUser": 1,
    "description": "Desc1",
    "sortOrder": "2",
    "catererId": "compasscrmtest"
}
*/