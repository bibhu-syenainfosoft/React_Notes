export interface ProductContract {
    Name: string;
    Price: number;
    Stock: boolean;
}