const FunctionalBased = () => (
    <div>
        <h2>FunctionalBasedPractice Component Works...</h2>
    </div>
)

export default FunctionalBased;