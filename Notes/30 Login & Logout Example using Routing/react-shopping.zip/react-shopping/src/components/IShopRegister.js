import axios from "axios";
import { useFormik } from "formik";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import * as yup from 'yup';

export default function IShopRegister() {
    const navigate = useNavigate();
    const formik = useFormik({
        initialValues: {
            id: 0,
            name: '',
            updatedUser: 1,
            description: '',
            sortOrder: '',
            catererId: 'compasscrmtest'
        },
        validationSchema: yup.object({
            name: yup.string().required('Name cannot be empty'),
            description: yup.string().required('Password cannot be empty'),
            sortOrder:yup.number('Sort Order must be digits only')
        }),
        onSubmit: async (values, { resetForm }) => {
            try {
                if (!values.sortOrder) {
                    values.sortOrder = 1;
                }
                await axios.post("https://testapps.aquilasoftware.com/CRMV1/maintenance/saveOrUpdateRoles", values);
                Swal.fire('Success', 'Data Saved Successfully', 'success');
                resetForm();
                navigate('/login');
            } catch (error) {
                Swal.fire('Error', 'Failed to save data', 'error');
                console.error('Error saving data:', error);
            }
        }
    });

    return (
        <div>
            <form onSubmit={formik.handleSubmit}>
                <dl>
                    <dt>Name <span className="text-danger">*</span></dt>
                    {/* <dd><input type="text" value={formik.values.name} name="name" onChange={formik.handleChange} className="w-25 rounded-1" /></dd> */}
                    <dd><input type="text" {...formik.getFieldProps('name')} className="w-25 rounded-1" /></dd>
                    <dd className="text-danger">{formik.errors.name}</dd>
                    <dt>Password <span className="text-danger">*</span></dt>
                    <dd><input type="password" {...formik.getFieldProps('description')} onChange={formik.handleChange} className="w-25 rounded-1" /></dd>
                    <dd className="text-danger">{formik.errors.description}</dd>
                    <dt>Sort Order</dt>
                    <dd><input type="text" {...formik.getFieldProps('sortOrder')}
                        //  onBlur={() => {
                        //     if (!formik.values.sortOrder) {
                        //         formik.setFieldValue('sortOrder', '1');
                        //     }
                        // }} 
                       className="rounded-1" /></dd>
                            <dd className="text-danger">{formik.errors.sortOrder}</dd>
                </dl>
                <div className="w-50 d-flex mx-5">
                    <div>
                        <button className="btn btn-outline-info">Register</button>
                    </div>
                    <div className="mx-3 mt-3">
                        <Link to="/login">Already have an account?</Link>
                    </div>
                </div>
            </form>
        </div>
    );
}


/*

FAQ. How to send and access Query params in React?
Ans. 

import React from 'react';
import { useLocation } from 'react-router-dom';

const UserInfo = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);

  const name = queryParams.get('name');
  const age = queryParams.get('age');

  return (
    <div>
      <h2>User Info</h2>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
    </div>
  );
};

export default UserInfo;

*/
