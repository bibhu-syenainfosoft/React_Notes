import { useEffect, useState } from "react";
import { useCookies } from "react-cookie"
import { useNavigate } from "react-router-dom";

export default function IShopDashboard(){
    const [cookie,setCookie,removeCookie] = useCookies();
    const [user,setUser] = useState();
    const navigate = useNavigate();

    useEffect(()=>{
        if(cookie['userid']==undefined){
            navigate("/login");
        }
        else
        setUser(cookie['userid']);
    },[]);

    function handleSignOut(){
        removeCookie('userid');
        navigate('/login');
    }

    return(
        <div className="mt-2">
            <center>
            <h3><b>Welcome,<i>{user}</i> To IShop Store Online</b></h3>
            <h4>Happy Shopping!!!</h4>
            <button onClick={handleSignOut} className="btn btn-outline-warning">SignOut</button>
            </center>
        </div>
    )
}