import axios from "axios";
import { useEffect, useState } from "react";
import { useParams,Link } from "react-router-dom"

export default function IShopProductDetails() {
    const param = useParams();
    const [product, setProduct] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let id = parseInt(param.id);
        axios.get(`https://fakestoreapi.com/products/${id}`).
            then(response => {
                setProduct(response.data);
                setLoading(false);
            })

    }, [param.id]);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h3 className="text-primary"><b>Product Details</b></h3>
            <dl>
                <dt><h5><b>Preview</b></h5></dt>
                <dd><img src={product.image} width='70' height='70' /></dd>
                <dt><h5><b>Price</b></h5></dt>
                <dd><span className="bi bi-currency-rupee">{product.price}</span></dd>
                <dt><h5><b>Title</b></h5></dt>
                <dd>{product.title}</dd>
                <dt><h5><b>Rating</b></h5></dt>
                <dd>
                    <span className="bi bi-star-fill text-warning"></span>
                    <span className="bi bi-star-fill text-warning"></span>
                    <span className="bi bi-star-fill text-warning"></span>
                    <span className="bi bi-star-fill text-warning"></span>
                    <span className="bi bi-star-half text-warning"></span>
                </dd>
                <dd>{product.rating.rate}</dd>
            </dl>
            <div className="ms-5">
                <Link to={'/products/'+product.category}>Back to Products</Link>
            </div>
        </div>
    )
}