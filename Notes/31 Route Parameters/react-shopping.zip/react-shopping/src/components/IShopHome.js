import { Link } from "react-router-dom";

export default function IShopHome(){
    return(
        <div>
            <h3><b>IShop-Home</b></h3>
            <Link to='/register'>New Register</Link><br /><br />
            <span>Already have account?</span><br />
            <Link to='/register'>Existing User</Link>
        </div>
    )
}