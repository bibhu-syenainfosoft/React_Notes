import { Link } from "react-router-dom"

export default function NRILogin(){
    return(
        <div className="container-fluid">
            <h2><b>NRI LOGIN...</b></h2>
            <Link to='/nri'>Back to NRI</Link>
        </div>
    )
}