import { Link } from "react-router-dom"

export default function NRIRegister(){
    return(
        <div className="container-fluid">
            <h2><b>NRI REGISTER...</b></h2>
            <Link to='/nri'>Back to NRI</Link>
        </div>
    )
}