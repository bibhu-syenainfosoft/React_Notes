import { Link } from "react-router-dom"

export default function NRILogin(){
    return(
        <div className="container-fluid">
            <h2><b>PERSONAL REGISTER...</b></h2>
            <Link to='/personal'>Back to Personal</Link>
        </div>
    )
}