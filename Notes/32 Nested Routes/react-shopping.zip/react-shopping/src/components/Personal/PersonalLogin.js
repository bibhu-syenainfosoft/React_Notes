import { Link } from "react-router-dom"

export default function PersonalLogin(){
    return(
        <div className="container-fluid">
            <h2><b>PERSONAL LOGIN...</b></h2>
            <Link to='/personal'>Back to Personal</Link>
        </div>
    )
}