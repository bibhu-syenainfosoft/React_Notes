import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
     <h2>Welcome to React</h2>
     <p>React is a JS library.</p>
    </div>
  );
}

export default App;
